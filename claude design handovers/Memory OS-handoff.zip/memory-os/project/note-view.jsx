// Note views — there are two flavours:
//   1. InboxNoteView    : raw intake (typed/dictated). Minimal chrome.
//   2. ProcessedNoteView: structured note in the Notes folder. Rich layout.

function fmtCreated(d) {
  const days = window.memDaysAgo(d);
  if (days <= 0) {
    const hours = Math.round((MEM_NOW - d) / 3600000);
    if (hours <= 0) return "just now";
    if (hours < 24) return `${hours}h ago`;
  }
  return fmtAge(d);
}

// ────────────────────────────────────────────────────────────
//  Inbox note view (intake)
// ────────────────────────────────────────────────────────────
function InboxNoteView({ note }) {
  const [title, setTitle] = React.useState(note.title || "");
  const [body, setBody]   = React.useState(note.body || "");
  const [dictating, setDictating]   = React.useState(false);
  const [processing, setProcessing] = React.useState(false);

  // Reset state when switching notes
  React.useEffect(() => {
    setTitle(note.title || "");
    setBody(note.body || "");
    setDictating(false);
    setProcessing(false);
  }, [note.id]);

  return (
    <div data-screen-label="Inbox note" style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      {/* Header — fixed date title (left) + action buttons (right) */}
      <header style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "24px 48px 20px",
        borderBottom: "1px solid var(--border-subtle)",
        gap: 16,
      }}>
        <div style={{
          fontSize: 13,
          color: "var(--text-very-dim)",
          letterSpacing: "0.04em",
          fontVariantNumeric: "tabular-nums",
        }}>
          {note.dateTitle.toUpperCase()}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <DictateButton active={dictating} onClick={() => setDictating(!dictating)} />
          <ProcessButton
            processing={processing}
            onClick={() => {
              setProcessing(true);
              setTimeout(() => setProcessing(false), 1800);
            }}
          />
        </div>
      </header>

      {/* Editable canvas — title + body */}
      <div style={{ flex: 1, padding: "32px 48px 48px", maxWidth: 760 }}>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Untitled — type a subject or leave blank"
          style={{
            display: "block",
            width: "100%",
            fontSize: 30,
            fontWeight: 600,
            letterSpacing: "-0.02em",
            color: "var(--text)",
            background: "transparent",
            border: "none",
            outline: "none",
            padding: 0,
            marginBottom: 20,
            fontFamily: "inherit",
          }}
        />
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Start typing, or hit Dictate…"
          style={{
            display: "block",
            width: "100%",
            minHeight: 420,
            fontSize: 15,
            lineHeight: 1.6,
            color: "var(--text-dim)",
            background: "transparent",
            border: "none",
            outline: "none",
            padding: 0,
            resize: "none",
            fontFamily: "inherit",
          }}
        />
      </div>
    </div>
  );
}

function DictateButton({ active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        padding: "8px 14px",
        background: active ? "oklch(0.70 0.18 22 / 0.16)" : "var(--panel)",
        color: active ? "oklch(0.84 0.16 22)" : "var(--text)",
        border: `1px solid ${active ? "oklch(0.70 0.18 22 / 0.40)" : "var(--border)"}`,
        borderRadius: 8,
        fontSize: 13,
        cursor: "pointer",
        fontFamily: "inherit",
        transition: "background .15s",
      }}
    >
      <span style={{
        width: 8, height: 8, borderRadius: "50%",
        background: active ? "oklch(0.75 0.20 22)" : "var(--text-very-dim)",
        boxShadow: active ? "0 0 0 4px oklch(0.70 0.18 22 / 0.20)" : "none",
        animation: active ? "pulse 1.2s ease-in-out infinite" : "none",
      }} />
      {active ? "Recording…" : "Dictate"}
    </button>
  );
}

function ProcessButton({ processing, onClick }) {
  return (
    <button
      onClick={onClick}
      disabled={processing}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        padding: "8px 14px",
        background: processing ? "oklch(0.80 0.13 80 / 0.18)" : "oklch(0.80 0.13 80 / 0.12)",
        color: "oklch(0.85 0.13 80)",
        border: "1px solid oklch(0.80 0.13 80 / 0.36)",
        borderRadius: 8,
        fontSize: 13,
        fontWeight: 500,
        cursor: processing ? "wait" : "pointer",
        fontFamily: "inherit",
        transition: "background .15s",
      }}
    >
      <Sparkle spinning={processing} />
      {processing ? "Processing…" : "Process note"}
    </button>
  );
}

function Sparkle({ spinning }) {
  return (
    <svg
      viewBox="0 0 16 16"
      width="13" height="13"
      fill="currentColor"
      style={{
        animation: spinning ? "sparkleSpin 1.2s linear infinite" : "none",
      }}
    >
      <path d="M8 1 L9.2 6.8 L15 8 L9.2 9.2 L8 15 L6.8 9.2 L1 8 L6.8 6.8 Z" />
    </svg>
  );
}

// ────────────────────────────────────────────────────────────
//  Processed note view (Notes folder)
// ────────────────────────────────────────────────────────────
function NoteBody({ blocks }) {
  return (
    <div style={{ maxWidth: 720, fontSize: 14.5, lineHeight: 1.65, color: "var(--text)" }}>
      {blocks.map((b, i) => {
        if (b.type === "p")  return <p key={i} style={{ margin: "0 0 16px", color: "var(--text-dim)", textWrap: "pretty" }}>{b.text}</p>;
        if (b.type === "h")  return (
          <h2 key={i} style={{
            fontSize: 13,
            fontWeight: 600,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            color: "var(--text-very-dim)",
            margin: "26px 0 12px",
          }}>{b.text}</h2>
        );
        if (b.type === "ul") return (
          <ul key={i} style={{ margin: "0 0 16px", paddingLeft: 0, listStyle: "none" }}>
            {b.items.map((it, j) => (
              <li key={j} style={{
                position: "relative",
                paddingLeft: 22,
                color: "var(--text-dim)",
                margin: "0 0 6px",
              }}>
                <span style={{
                  position: "absolute", left: 6, top: "0.7em",
                  width: 4, height: 4, borderRadius: "50%",
                  background: "var(--text-very-dim)",
                }} />
                {it}
              </li>
            ))}
          </ul>
        );
        if (b.type === "ol") return (
          <ol key={i} style={{ margin: "0 0 16px", paddingLeft: 22, color: "var(--text-dim)" }}>
            {b.items.map((it, j) => (
              <li key={j} style={{ margin: "0 0 6px" }}>{it}</li>
            ))}
          </ol>
        );
        return null;
      })}
    </div>
  );
}

function NoteAction({ label, hue, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 12px",
        background: `oklch(0.78 0.13 ${hue} / 0.10)`,
        color: `oklch(0.84 0.13 ${hue})`,
        border: `1px solid oklch(0.78 0.13 ${hue} / 0.30)`,
        borderRadius: 999,
        fontSize: 12.5,
        cursor: "pointer",
        fontFamily: "inherit",
      }}
      onMouseEnter={(e) => e.currentTarget.style.background = `oklch(0.78 0.13 ${hue} / 0.18)`}
      onMouseLeave={(e) => e.currentTarget.style.background = `oklch(0.78 0.13 ${hue} / 0.10)`}
    >
      <span style={{
        width: 5, height: 5, borderRadius: "50%",
        background: `oklch(0.78 0.16 ${hue})`,
      }} />
      {label}
    </button>
  );
}

function BacklinkChip({ id }) {
  let label = id;
  const p = MEM_PROJECTS.find((x) => x.id === id);
  if (p) label = p.title;
  const person = MEM_PEOPLE.find((x) => x.id === id);
  if (person) label = person.name;
  const idea = MEM_IDEAS.find((x) => x.id === id);
  if (idea) label = idea.title;
  return (
    <span style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "4px 10px",
      borderRadius: 6,
      background: "var(--panel-2)",
      border: "1px solid var(--border-subtle)",
      color: "var(--text-dim)",
      fontSize: 12,
      cursor: "pointer",
    }}>
      <span style={{ color: "var(--text-very-dim)" }}>↳</span>
      {label}
    </span>
  );
}

function ProcessedNoteView({ note }) {
  return (
    <div data-screen-label="Note">
      <header style={{ padding: "32px 48px 24px", borderBottom: "1px solid var(--border-subtle)" }}>
        <div style={{
          display: "flex",
          gap: 14,
          alignItems: "center",
          fontSize: 12,
          color: "var(--text-very-dim)",
          marginBottom: 14,
          flexWrap: "wrap",
        }}>
          <span style={{ letterSpacing: "0.04em" }}>
            {note.created.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }).toUpperCase()}
            {" · "}
            {fmtCreated(note.created)}
          </span>
          <span style={{ color: "var(--border-strong)" }}>·</span>
          <AgeChip date={note.created} />
          <span style={{ display: "inline-flex", gap: 6, flexWrap: "wrap" }}>
            {note.tags.map((t) => <Tag key={t}>#{t}</Tag>)}
          </span>
        </div>
        <h1 style={{
          fontSize: 30,
          fontWeight: 600,
          letterSpacing: "-0.02em",
          margin: 0,
          color: "var(--text)",
          maxWidth: 720,
          textWrap: "balance",
        }}>{note.title}</h1>
      </header>

      <section style={{ padding: "28px 48px 12px" }}>
        <NoteBody blocks={note.body} />
      </section>

      {note.backlinks?.length > 0 && (
        <section style={{ padding: "8px 48px 4px" }}>
          <SectionHeader label="Linked" />
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {note.backlinks.map((id) => <BacklinkChip key={id} id={id} />)}
          </div>
        </section>
      )}

      <section style={{ padding: "24px 48px 48px", marginTop: 12 }}>
        <SectionHeader label="Process" />
        <div style={{
          display: "flex",
          gap: 10,
          flexWrap: "wrap",
          padding: "16px 18px",
          background: "var(--panel)",
          border: "1px solid var(--border)",
          borderRadius: 10,
        }}>
          <NoteAction label="Convert to task"    hue={230} />
          <NoteAction label="Convert to idea"    hue={80}  />
          <NoteAction label="Attach to project"  hue={150} />
          <NoteAction label="Add to person"      hue={260} />
          <span style={{ marginLeft: "auto", display: "inline-flex", gap: 10 }}>
            <NoteAction label="Archive"          hue={22}  />
          </span>
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { InboxNoteView, ProcessedNoteView });
