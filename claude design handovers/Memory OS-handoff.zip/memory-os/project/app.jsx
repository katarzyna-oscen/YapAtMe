// Root app

function App() {
  const [view, setView] = React.useState({ type: "dashboard" });

  const stats = React.useMemo(() => {
    const stale = MEM_PROJECTS.filter(p => ageDays(p.touched) >= 14).length;
    return {
      projects: MEM_PROJECTS.length,
      stale,
      actions: MEM_ACTIONS.filter(a => !a.done).length,
    };
  }, []);

  const renderView = () => {
    if (view.type === "inbox-note") {
      const note = MEM_INBOX.find((n) => n.id === view.id);
      if (note) return <InboxNoteView note={note} />;
    }
    if (view.type === "note") {
      const note = MEM_NOTES.find((n) => n.id === view.id);
      if (note) return <ProcessedNoteView note={note} />;
    }
    // Default: dashboard
    return (
      <React.Fragment>
        <TopBar stats={stats} />
        <NeedsCallRow items={MEM_NEEDS_CALL} />
        <ProjectsSection />
        <ActionsSection />
        <PeopleSection />
        <IdeasSection />
      </React.Fragment>
    );
  };

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden", background: "var(--bg)" }}>
      <Sidebar view={view} onNavigate={setView} />
      <main
        style={{ flex: 1, overflowY: "auto", color: "var(--text)" }}
        data-screen-label={
          view.type === "inbox-note" ? "Inbox note"
          : view.type === "note" ? "Note"
          : "Dashboard"
        }
      >
        {renderView()}
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
