// Memory OS — seed data
// Status taxonomy used across the dashboard:
//   building      → in active development (green)
//   triaged       → scoped, waiting to start (amber)
//   to-be-deployed→ done, awaiting deploy (blue)
//   needs-call    → blocked / decision needed (red)
//   idle          → not touched recently (slate)

const NOW = new Date("2026-05-22T16:48:00Z");
const daysAgo = (n) => new Date(NOW.getTime() - n * 86400000);

const STATUS = {
  "building":      { label: "Building",       hue: 150 },
  "triaged":       { label: "Triaged",        hue: 80  },
  "to-be-deployed":{ label: "To Be Deployed", hue: 230 },
  "needs-call":    { label: "Needs Your Call",hue: 25  },
  "idle":          { label: "Idle",           hue: 260 },
};

const PROJECTS = [
  {
    id: "content-system",
    title: "Content System",
    status: "to-be-deployed",
    summary: "There is no one-stop-shop solution for everything Sites related and no self-service flow for marketing.",
    tags: ["Sites", "Apps"],
    touched: daysAgo(11),
    openActions: 2,
    progress: 0.85,
  },
  {
    id: "ia-framework",
    title: "Information Architecture Framework For Product Bubbles",
    status: "triaged",
    summary: "Each product bubble has different IA architecture which does not provide unified experience.",
    tags: ["IA", "Sites", "Product"],
    touched: daysAgo(18),
    openActions: 4,
    progress: 0.2,
  },
  {
    id: "memory-os-app",
    title: "Memory OS App",
    status: "building",
    summary: "My brain is overloaded — need a system to process ideas and daily tasks.",
    tags: ["AI", "apps", "hackathon"],
    touched: daysAgo(1),
    openActions: 6,
    progress: 0.45,
  },
  {
    id: "ubuntucom-revamp",
    title: "Ubuntu.com Home Page Revamp",
    status: "triaged",
    summary: "Ubuntu.com is outdated and old although it is our flagship website with huge traffic.",
    tags: ["Ubuntu", "Sites"],
    touched: daysAgo(23),
    openActions: 3,
    progress: 0.1,
  },
  {
    id: "design-tokens-v2",
    title: "Design Tokens v2",
    status: "building",
    summary: "Reconcile semantic tokens across Vanilla, Canonical brand, and product surfaces.",
    tags: ["DS", "infra"],
    touched: daysAgo(3),
    openActions: 5,
    progress: 0.55,
  },
  {
    id: "hackathon-demo",
    title: "Hackathon Demo Prep",
    status: "needs-call",
    summary: "Demo slot is Friday. Need to decide which two flows to show and who presents.",
    tags: ["events"],
    touched: daysAgo(2),
    openActions: 7,
    progress: 0.3,
  },
];

const PEOPLE = [
  { id: "elaine",    name: "Elaine Liman",     role: "UX designer / Prof I",  touched: daysAgo(2),  initials: "EL", note: "1:1 prep",            cadence: 5 },
  { id: "katarzyna", name: "Katarzyna Duda",   role: "Design manager",         touched: daysAgo(5),  initials: "KD", note: "Q3 review",           cadence: 4 },
  { id: "sophie",    name: "Sophie Felder",    role: "UX designer / Prof II",  touched: daysAgo(9),  initials: "SF", note: "shadow IA project",   cadence: 3 },
  { id: "marcus",    name: "Marcus Chen",      role: "Engineering lead",       touched: daysAgo(14), initials: "MC", note: "deploy pipeline",     cadence: 2 },
  { id: "priya",     name: "Priya Shah",       role: "Product manager",        touched: daysAgo(21), initials: "PS", note: "roadmap sync",        cadence: 2 },
  { id: "tomas",     name: "Tomáš Reyes",      role: "User researcher",        touched: daysAgo(28), initials: "TR", note: "interview synthesis", cadence: 1 },
];

const IDEAS = [
  { id: "ai-memory-os",     title: "AI Memory OS",          status: "building", touched: daysAgo(1) },
  { id: "daily-review",     title: "Daily review ritual",   status: "triaged",  touched: daysAgo(6) },
  { id: "project-health",   title: "Project health score",  status: "triaged",  touched: daysAgo(12) },
  { id: "smart-inbox",      title: "Smart inbox triage",    status: "idle",     touched: daysAgo(34) },
  { id: "weekly-digest",    title: "Friday weekly digest",  status: "idle",     touched: daysAgo(41) },
];

const ACTIONS = [
  { id: "a1", text: "Reply to Katarzyna re: Q3 review agenda",          project: "—",                   created: daysAgo(1),  done: false },
  { id: "a2", text: "Cut hackathon demo to 2 flows + assign presenters",project: "Hackathon Demo Prep", created: daysAgo(3),  done: false },
  { id: "a3", text: "Audit Ubuntu.com nav for IA framework draft",      project: "IA Framework",        created: daysAgo(8),  done: false },
  { id: "a4", text: "Wire deploy step for Content System",              project: "Content System",      created: daysAgo(2),  done: false },
  { id: "a5", text: "Draft Memory OS dashboard spec",                   project: "Memory OS App",       created: daysAgo(5),  done: true  },
  { id: "a6", text: "Send Sophie scope notes for shadow IA",            project: "IA Framework",        created: daysAgo(17), done: false },
  { id: "a7", text: "Decide token naming: --color-* vs --c-*",          project: "Design Tokens v2",    created: daysAgo(11), done: false },
];

// Needs your call: priority items surfaced from elsewhere in the system.
// Deliberately heterogeneous — projects, people, and ideas can all bubble up here.
const NEEDS_CALL = [
  { kind: "project", id: "hackathon-demo", reason: "demo Friday — decide presenters",  age: 2 },
  { kind: "person",  id: "tomas",          reason: "no contact in 4 weeks",            age: 28 },
  { kind: "project", id: "ubuntucom-revamp", reason: "triaged 23 days — start or drop", age: 23 },
];

// Activity: count of touched items per day, last 12 weeks (84 days).
// Seeded so it looks like a real working week rhythm.
const ACTIVITY = (() => {
  const out = [];
  let seed = 7;
  const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  for (let i = 83; i >= 0; i--) {
    const d = new Date(NOW.getTime() - i * 86400000);
    const dow = d.getDay();
    const weekend = (dow === 0 || dow === 6);
    const base = weekend ? rand() * 1.2 : rand() * 5 + 1;
    const v = Math.max(0, Math.round(base + (rand() < 0.12 ? 4 : 0)));
    out.push({ date: d, count: v });
  }
  // Make today substantial
  out[out.length - 1].count = 7;
  out[out.length - 2].count = 4;
  return out;
})();

// INBOX_NOTES — raw intake, typed or dictated. Body is plain text.
// The "title" of the file on disk is always the date; the title field below is
// an optional human-readable subtitle the user can add before processing.
const INBOX_NOTES = [
  {
    id: "inbox-2026-05-22-1648",
    dateTitle: "2026-05-22 · Friday 16:48",
    title: "",
    body: `sophie sent three references for the IA framework in #design this morning

- atlassian product nav patterns (the "bubble" model)
- stripe docs IA case study from 2024
- notion internal IA RFC (in DM, redact before circulating)

worth a look before the ubuntu.com revamp kickoff. all three argue for shared scaffold + local affordances — probably where we land too.

todo
- skim end to end before friday
- pull two diagrams into IA framework note
- ping sophie monday to compare reads`,
  },
  {
    id: "inbox-2026-05-21-0912",
    dateTitle: "2026-05-21 · Thursday 09:12",
    title: "deploy script swallows errors",
    body: `publish script exits 0 even when the cdn upload fails. only noticed because pages 404 in prod.

repro
- trigger deploy with bad cdn token
- watch log say "done."
- hit url → 404

fix
- wrap upload in set -e, propagate non-zero exit
- add smoke test that fetches index post-deploy, asserts 200

ask marcus about the deploy job runner config — there might be a flag we already have.`,
  },
  {
    id: "inbox-2026-05-20-2204",
    dateTitle: "2026-05-20 · Wednesday 22:04",
    title: "",
    body: `idea — weekly digest email every friday 5pm

what changed across projects (status moves, age)
people not touched in 14+ days
ideas sitting in triaged too long
one "focus suggestion" for next week from needs your call

composes nicely with the daily review ritual idea. daily for noise, weekly for shape.`,
  },
];

// NOTES — processed, structured. Lives in the Notes folder; file id is the date.
const NOTES = [
  {
    id: "2026-05-22",
    title: "Sophie sent IA references",
    created: daysAgo(0),
    tags: ["ia", "research", "from:sophie"],
    body: [
      { type: "p", text: "Sophie dropped three IA references in the design channel this morning — worth a look before the Ubuntu.com revamp kickoff." },
      { type: "h", text: "Links" },
      { type: "ul", items: [
        "Atlassian product navigation patterns — “bubble” model",
        "Stripe Docs IA case study from 2024",
        "Notion's internal IA RFC (shared in DM, redact before circulating)",
      ]},
      { type: "h", text: "Why this matters" },
      { type: "p", text: "We've been going back and forth on whether to unify nav across product bubbles or let each have a tailored IA. These references all argue for a shared scaffold + local affordances — likely where we should land too." },
      { type: "h", text: "Next" },
      { type: "ul", items: [
        "Skim the three references end-to-end (45min)",
        "Pull two diagrams into the IA Framework note",
        "Ping Sophie to compare reads on Monday",
      ]},
    ],
    backlinks: ["ia-framework", "ubuntucom-revamp", "sophie"],
  },
  {
    id: "2026-05-21",
    title: "Bug — deploy script silently swallows errors",
    created: daysAgo(1),
    tags: ["bug", "infra"],
    body: [
      { type: "p", text: "Found while wiring up the Content System deploy step. The publish script exits 0 even when the upload to the CDN fails — we only notice because pages 404 in production." },
      { type: "h", text: "Repro" },
      { type: "ol", items: [
        "Trigger a deploy with an invalid CDN token (env var swap)",
        "Watch the job log — “Done.” appears at the end",
        "Hit the deployed URL → 404",
      ]},
      { type: "h", text: "Likely fix" },
      { type: "p", text: "Wrap the upload step in `set -e` or explicitly propagate the non-zero exit. Worth adding a smoke test that fetches the published index after deploy and asserts 200." },
    ],
    backlinks: ["content-system", "marcus"],
  },
  {
    id: "2026-05-20",
    title: "Idea — weekly digest email",
    created: daysAgo(2),
    tags: ["idea", "memory-os"],
    body: [
      { type: "p", text: "Every Friday at 5pm, Memory OS sends me a digest covering the week:" },
      { type: "ul", items: [
        "What changed across projects (status moves, age)",
        "People I haven't touched in 14+ days",
        "Ideas that have been sitting in Triaged for too long",
        "One “focus suggestion” for next week, picked from Needs Your Call",
      ]},
      { type: "p", text: "Should compose well with the daily review ritual idea — daily for noise, weekly for shape." },
    ],
    backlinks: ["ai-memory-os", "daily-review"],
  },
  {
    id: "2026-05-19",
    title: "1:1 — Katarzyna · Q3 review prep",
    created: daysAgo(3),
    tags: ["1-1", "from:katarzyna"],
    body: [
      { type: "p", text: "Half-hour prep for Q3 review. Katarzyna wants three artefacts: shipped work, in-flight bets, and one open ask." },
      { type: "h", text: "Shipped" },
      { type: "ul", items: [
        "Content System (to-be-deployed)",
        "Design Tokens v1 review",
        "Two onboarding studies with the research team",
      ]},
      { type: "h", text: "In flight" },
      { type: "ul", items: [
        "IA Framework — still scoping",
        "Memory OS App — building",
        "Ubuntu.com revamp — triaged",
      ]},
      { type: "h", text: "Ask" },
      { type: "p", text: "More dedicated research time for IA Framework before kickoff. Either pull Tomáš in for two weeks or push the kickoff back a sprint." },
    ],
    backlinks: ["katarzyna", "ia-framework"],
  },
];

Object.assign(window, {
  MEM_NOW: NOW,
  MEM_STATUS: STATUS,
  MEM_PROJECTS: PROJECTS,
  MEM_PEOPLE: PEOPLE,
  MEM_IDEAS: IDEAS,
  MEM_ACTIONS: ACTIONS,
  MEM_NEEDS_CALL: NEEDS_CALL,
  MEM_ACTIVITY: ACTIVITY,
  MEM_INBOX: INBOX_NOTES,
  MEM_NOTES: NOTES,
  memDaysAgo: (d) => Math.round((NOW - d) / 86400000),
});
