// Root app

function App() {
  const [view, setView] = React.useState({ type: "dashboard" });
  const [inbox, setInbox]     = React.useState(MEM_INBOX);
  const [notes, setNotes]     = React.useState(MEM_NOTES);
  const [archive, setArchive] = React.useState([]);
  const [pending, setPending] = React.useState(null); // { action, source, item }

  const stats = React.useMemo(() => {
    const stale = MEM_PROJECTS.filter(p => ageDays(p.touched) >= 14).length;
    return {
      projects: MEM_PROJECTS.length,
      stale,
      actions: MEM_ACTIONS.filter(a => !a.done).length,
    };
  }, []);

  // Sidebar 3-dot menu: request archive/delete for a note or inbox item.
  // Always routes through a confirmation modal — both are destructive in spirit.
  const handleItemAction = (action, source, item) => {
    setPending({ action, source, item });
  };

  const cancelPending = () => setPending(null);

  const commitPending = () => {
    if (!pending) return;
    const { action, source, item } = pending;
    const removeFrom = source === "inbox" ? setInbox : setNotes;
    const list       = source === "inbox" ? inbox    : notes;
    const removed    = list.find((x) => x.id === item.id);
    removeFrom((arr) => arr.filter((x) => x.id !== item.id));
    if (action === "archive" && removed) {
      setArchive((arr) => [{ id: removed.id, label: item.label }, ...arr]);
    }
    // If the active view was this item, fall back to the dashboard.
    if ((view.type === "inbox-note" || view.type === "note") && view.id === item.id) {
      setView({ type: "dashboard" });
    }
    setPending(null);
  };

  const renderView = () => {
    if (view.type === "inbox-note") {
      const note = inbox.find((n) => n.id === view.id);
      if (note) return (
        <InboxNoteView
          note={note}
          onAction={(action, item) => handleItemAction(action, "inbox", item)}
        />
      );
    }
    if (view.type === "note") {
      const note = notes.find((n) => n.id === view.id);
      if (note) return (
        <ProcessedNoteView
          note={note}
          onAction={(action, item) => handleItemAction(action, "note", item)}
        />
      );
    }
    return (
      <React.Fragment>
        <TopBar stats={stats} />
        <NeedsCallRow items={MEM_NEEDS_CALL} />
        <ProjectsSection />
        <ActionsSection />
        <PeopleSection />
        <IdeasSection />
      </React.Fragment>
    );
  };

  const dialogCopy = pending && (() => {
    const kind = pending.source === "inbox" ? "inbox note" : "note";
    if (pending.action === "delete") {
      return {
        title: `Delete ${kind}?`,
        message: `“${pending.item.label}” will be permanently removed. This action cannot be undone.`,
        confirmLabel: "Delete",
        danger: true,
      };
    }
    return {
      title: `Archive ${kind}?`,
      message: `“${pending.item.label}” will be moved to the Archive. You can restore it later from the Archive section.`,
      confirmLabel: "Archive",
      danger: true,
    };
  })();

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden", background: "var(--bg)" }}>
      <Sidebar
        view={view}
        onNavigate={setView}
        onItemAction={handleItemAction}
        inbox={inbox}
        notes={notes}
        archive={archive}
      />
      <main
        style={{ flex: 1, overflowY: "auto", color: "var(--text)" }}
        data-screen-label={
          view.type === "inbox-note" ? "Inbox note"
          : view.type === "note" ? "Note"
          : "Dashboard"
        }
      >
        {renderView()}
      </main>
      <ConfirmDialog
        open={!!pending}
        title={dialogCopy?.title}
        message={dialogCopy?.message}
        confirmLabel={dialogCopy?.confirmLabel}
        danger={dialogCopy?.danger}
        onConfirm={commitPending}
        onCancel={cancelPending}
      />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
